#define _GNU_SOURCE
#include <stdio.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>
#include <time.h>
#include <sched.h>
#include <unistd.h>
#include <x86intrin.h>

void shuffle_array(char array[], size_t length) {
    srand(time(NULL));
    for (size_t i = 0; i < length; i++) {
        size_t j = rand() % length;
        char temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }
}

void fill_array(char array[], size_t length) {
    for (size_t i = 0; i < length*0.5; i++) {
        array[i] = '1'; // A1
    }
    for (size_t i = length*0.5; i < length; i++) {
        array[i] = '2'; // B1
    }
    shuffle_array(array, length);
    shuffle_array(array, length);
    shuffle_array(array, length);
}

int main(int argc, char const *argv[]) {
    cpu_set_t set;
    CPU_ZERO(&set);
    CPU_SET(0, &set); // Use core 0
    sched_setaffinity(0, sizeof(cpu_set_t), &set);
    
    // pause to please our lord and savior, the scheduler
    sleep(5);
    
    int sock = 0;
    struct sockaddr_in serv_addr;
    char buffer[1024] = {0};
	unsigned long long start, end, time_spent;


    if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        printf("\n Socket creation error \n");
        return -1;
    }

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(8080);

    if(inet_pton(AF_INET, "127.0.0.1", &serv_addr.sin_addr)<=0) {
        printf("\nInvalid address/ Address not supported \n");
        return -1;
    }

    if (connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0) {
        printf("\nConnection Failed \n");
        return -1;
    }

    char array[1000000];
    fill_array(array, 1000000);

    printf("V1,V2\n");
	for(int i= 0; i<1000000;i++)
	{		
		// start measuring time
		start = __rdtsc();
		
		send(sock , &array[i] , 1 , 0 );
		read(sock , buffer, 2);
        
		// end measuring time
		end = __rdtsc();

		time_spent = end - start;
    
        if (array[i] == '1') {
            printf("BASELINE,%llu\n",time_spent);
        }  else {
            printf("MODIFIED,%llu\n",time_spent);
        }
	}
    return 0;
}
